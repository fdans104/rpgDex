const classe1Select = document.getElementById('classe1');
const classeSuporteSelect = document.getElementById('classeSuporte');
const resetBtn = document.getElementById('resetBtn');

const combinacoes = {
  // Combinações de classes (Guerreiro)
  guerreiro_mago: { nome: "Espadachim Místico", imagem: "imagensteste/Classe2H/espadachimmistico.png" },
  guerreiro_agil: { nome: "Samurai", imagem: "imagensteste/Classe2H/samurai.png" },
  guerreiro_fiel: { nome: "Paladino", imagem: "imagensteste/Classe2H/paladino.png" },
  guerreiro_academico: { nome: "Sentinela", imagem: "imagensteste/Classe2H/sentinela.png" },

  // Combinações de classes (Mago)
  mago_guerreiro: { nome: "Druida", imagem: "imagensteste/Classe2H/druida.png" },
  mago_agil: { nome: "Ilusionista", imagem: "imagensteste/Classe2H/ilusionista.png" },
  mago_fiel: { nome: "Necromante", imagem: "imagensteste/Classe2H/necromante.png" },
  mago_academico: { nome: "Erudita", imagem: "imagensteste/Classe2H/erudita.png" },

  // Combinações de classes (Ágil)
  agil_guerreiro: { nome: "Assassino", imagem: "imagensteste/Classe2H/assassino.png" },
  agil_mago: { nome: "Bardo", imagem: "imagensteste/Classe2H/bardo.png" },
  agil_fiel: { nome: "Caçador de Demônios", imagem: "imagensteste/Classe2H/cacadordemonios.png" },
  agil_academico: { nome: "Envenenador", imagem: "imagensteste/Classe2H/envenenador.png" },

  // Combinações de classes (Fiel)
  fiel_guerreiro: { nome: "Clérigo de Batalha", imagem: "imagensteste/Classe2H/clerigodebatalha.png" },
  fiel_mago: { nome: "Exorcista", imagem: "imagensteste/Classe2H/exorcista.png" },
  fiel_agil: { nome: "Monge", imagem: "imagensteste/Classe2H/monge.png" },
  fiel_academico: { nome: "Padre", imagem: "imagensteste/Classe2H/padre.png" },

  // Combinações de classes (Acadêmico)
  academico_guerreiro: { nome: "Ferreiro", imagem: "imagensteste/Classe2H/ferreiro.png" },
  academico_mago: { nome: "Alquimista", imagem: "imagensteste/Classe2H/alquimista.png" },
  academico_agil: { nome: "Armadilheiro", imagem: "imagensteste/Classe2H/armadilheiro.png" },
  academico_fiel: { nome: "Historiador", imagem: "imagensteste/Classe2H/historiador.png" }
};

let classePrincipalSelecionada = "guerreiro"; // Pra começar com o guerreiro selecionado

function atualizarClasse3() {
  const c1 = classePrincipalSelecionada;
  const c2 = classeSuporteSelect.value;
  const key = `${c1}_${c2}`;

  const card = document.getElementById('classe3Card');
  const carrosselPrincipal = document.getElementById('carouselRPG');
  const carrosselAvancado = document.getElementById('carouselClasseAvancada');

  if (c1 && c2 && c1 !== c2 && combinacoes[key]) {
    // Esconde o card central
    if (card) card.style.display = 'none';
    // Esconde o carrossel principal
    if (carrosselPrincipal && carrosselPrincipal.parentElement) {
      carrosselPrincipal.parentElement.style.display = 'none';
    }
    // Mostra o carrossel avançado
    if (carrosselAvancado && carrosselAvancado.parentElement) {
      carrosselAvancado.parentElement.style.display = 'block';
      // Move para o slide correto
      const resultado = combinacoes[key];
      const slideId = resultado.nome
        .toLowerCase()
        .normalize('NFD').replace(/[\u0300-\u036f]/g, '') // remove acentos
        .replace(/\s/g, '');
      const idx = Array.from(carrosselAvancado.querySelectorAll('.carousel-item'))
        .findIndex(item => item.id === slideId);
      if (idx >= 0) {
        const carouselInstance = bootstrap.Carousel.getOrCreateInstance(carrosselAvancado);
        carouselInstance.to(idx);
      }
    }
  } else {
    // Esconde o card central
    if (card) card.style.display = 'none';
    // Mostra carrossel principal
    if (carrosselPrincipal && carrosselPrincipal.parentElement) {
      carrosselPrincipal.parentElement.style.display = 'block';
    }
    // Esconde carrossel avançado
    if (carrosselAvancado && carrosselAvancado.parentElement) {
      carrosselAvancado.parentElement.style.display = 'none';
    }
  }

  atualizarDisponibilidade();
}

function atualizarDisponibilidade() {
  const c1 = classePrincipalSelecionada;
  const c2 = classeSuporteSelect.value;

  // Desabilita imagens de suporte que são iguais à principal
  document.querySelectorAll('.classe-img[data-target="classeSuporte"]').forEach(img => {
    img.classList.remove('disabled-img');
    if (img.dataset.classe === c1) {
      img.classList.add('disabled-img');
    }
  });
}

classeSuporteSelect.addEventListener('change', () => {
  atualizarImagemSelecionada('classeSuporte', classeSuporteSelect.value);
  atualizarClasse3();
});

document.querySelectorAll('.classe-img[data-target="classeSuporte"]').forEach(img => {
  img.addEventListener('click', () => {
    if (img.classList.contains('disabled-img')) return;
    const classe = img.dataset.classe;
    classeSuporteSelect.value = classe;
    atualizarImagemSelecionada('classeSuporte', classe);
    atualizarClasse3();
  });
});

resetBtn.addEventListener('click', () => {

  classeSuporteSelect.selectedIndex = 0;

  document.querySelectorAll('.classe-img').forEach(img => {
    img.classList.remove('selected');
    img.classList.remove('disabled-img');
  });

  atualizarDisponibilidade();
  const carrosselPrincipal = document.getElementById('carouselRPG');
  const carrosselAvancado = document.getElementById('carouselClasseAvancada');
  if (carrosselPrincipal && carrosselPrincipal.parentElement) {
    carrosselPrincipal.parentElement.style.display = 'block';
  }
  if (carrosselAvancado && carrosselAvancado.parentElement) {
    carrosselAvancado.parentElement.style.display = 'none';
  }
});

function atualizarImagemSelecionada(target, valor) {
  document.querySelectorAll(`.classe-img[data-target="${target}"]`)
    .forEach(img => img.classList.remove('selected'));
  const nova = document.querySelector(`.classe-img[data-target="${target}"][data-classe="${valor}"]`);
  if (nova) nova.classList.add('selected');
}

document.querySelectorAll('.quick-link-btn').forEach((btn, idx) => {
  btn.addEventListener('click', () => {
    classePrincipalSelecionada = btn.textContent.trim().toLowerCase();

    // Destaca o botão selecionado
    document.querySelectorAll('.quick-link-btn').forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');

    // REMOVE O DESTAQUE DAS IMAGENS DE SUPORTE
    document.querySelectorAll('.classe-img[data-target="classeSuporte"]').forEach(img => {
      img.classList.remove('selected');
    });

    // Sincroniza o carrossel principal com a seleção
    const carousel = document.getElementById('carouselRPG');
    if (carousel) {
      const carouselInstance = bootstrap.Carousel.getOrCreateInstance(carousel);
      carouselInstance.to(idx);
    }

    classeSuporteSelect.selectedIndex = 0;
    document.getElementById('carouselClasseAvancada').parentElement.style.display = 'none';
    carousel.parentElement.style.display = 'block';

    atualizarDisponibilidade();
    atualizarClasse3();
  });
});

// Destaca o botão do guerreiro ao carregar a página
window.addEventListener('DOMContentLoaded', () => {
  document.querySelector('.quick-link-btn.guerreiro').classList.add('selected');
  const carousel = document.getElementById('carouselRPG');
  if (carousel) {
    const carouselInstance = bootstrap.Carousel.getOrCreateInstance(carousel);
    carouselInstance.to(0);
  }
  atualizarDisponibilidade();
  atualizarClasse3();
});

// Sincroniza destaque ao navegar pelo carrossel
document.getElementById('carouselRPG').addEventListener('slid.bs.carousel', function (e) {
  const activeItem = e.target.querySelector('.carousel-item.active');
  if (activeItem && activeItem.id) {
    classePrincipalSelecionada = activeItem.id;
    document.querySelectorAll('.quick-link-btn').forEach(b => b.classList.remove('selected'));
    const btn = document.querySelector(`.quick-link-btn.${activeItem.id}`);
    if (btn) btn.classList.add('selected');
    atualizarDisponibilidade();
    atualizarClasse3();
  }
});

window.addEventListener('DOMContentLoaded', () => {
  // Sincroniza o carrossel principal com a seleção inicial
  const carousel = document.getElementById('carouselRPG');
  if (carousel) {
    const carouselInstance = bootstrap.Carousel.getOrCreateInstance(carousel);
    carouselInstance.to(0); // Slide do guerreiro
  }
  atualizarDisponibilidade();
  atualizarClasse3();
});